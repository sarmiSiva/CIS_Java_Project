/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.RMIInterface;

import java.rmi.RemoteException;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import jdk.nashorn.internal.runtime.arrays.ArrayLikeIterator;

/**
 *
 * @author Sarmila Sivaraja
 */
public class Server implements RMI_Interface{
    
    int[][] answerSet = new int[5][6];
    ArrayList<String> completedList = new ArrayList<String>();

    @Override
    public boolean SignIn(String user, String pass) throws RemoteException {
        boolean res=false;
        PreparedStatement pst;
        ResultSet rs;
        
      
        try {
            Class.forName("com.mysql.jdbc.Driver");
            
            java.sql.Connection con = DriverManager.getConnection("jdbc:mysql://remotemysql.com:3306/pTuLo9BMYw","pTuLo9BMYw", "Je9bAr9W0e");
            pst = (PreparedStatement) con.prepareStatement("SELECT * FROM `Student` WHERE StudentID=? AND Password=?");
            pst.setString(1, user);
            pst.setString(2, pass);
            
            rs = pst.executeQuery();
          
           if(rs.next()){
               res=true;
           }
   
        } catch (Exception e) {
            System.out.println(e.toString());
        }
        return res;
    }

    @Override
    public int[][] getFeedback(int[] ans) throws RemoteException {
        int col=0;
        for (int i = 0; i < ans.length; i++) {
            //saving the Q1 answer
            
                //saving the user answer to corresponding question's answers
                if(ans[i]==1){
                    answerSet[col][i]=answerSet[col][i]+1;
                }
                
                if(ans[i]==2){
                    answerSet[col+1][i]=answerSet[col+1][i]+1;
                }
                
                if(ans[i]==3){
                    answerSet[col+2][i]=answerSet[col+2][i]+1;
                }
                
                if(ans[i]==4){
                    answerSet[col+3][i]=answerSet[col+3][i]+1;
                }
                
                if(ans[i]==5){
                    answerSet[col+4][i]=answerSet[col+4][i]+1;
                }
                
                
            
            col=0;
        }
            
        
        return answerSet;
    }

    @Override
    public String[] genarateChart() throws RemoteException {
        String[] urlSet = new String[6];
        
        String url1 = "https://quickchart.io/chart?devicePixelRatio=1.0&c={type:'bar',data:{labels:['✰','✰✰','✰✰✰','✰✰✰✰','✰✰✰✰✰'], datasets:[{label:'1. Academics Syllabus content , Teaching method, Teaching guidance',data:["+answerSet[0][0]+","+answerSet[1][0]+","+answerSet[2][0]+","+answerSet[3][0]+","+answerSet[4][0]+"]}]}}";
        String url2 = "https://quickchart.io/chart?devicePixelRatio=1.0&c={type:'bar',data:{labels:['✰','✰✰','✰✰✰','✰✰✰✰','✰✰✰✰✰'], datasets:[{label:'2. Class room,internet, hostal, Library facilities',data:["+answerSet[0][1]+","+answerSet[1][1]+","+answerSet[2][1]+","+answerSet[3][1]+","+answerSet[4][1]+"]}]}}";
        String url3 = "https://quickchart.io/chart?devicePixelRatio=1.0&c={type:'bar',data:{labels:['✰','✰✰','✰✰✰','✰✰✰✰','✰✰✰✰✰'], datasets:[{label:'3. Events context, time management, venue arrangement',data:["+answerSet[0][2]+","+answerSet[1][2]+","+answerSet[2][2]+","+answerSet[3][2]+","+answerSet[4][2]+"]}]}}";
        String url4 = "https://quickchart.io/chart?devicePixelRatio=1.0&c={type:'bar',data:{labels:['✰','✰✰','✰✰✰','✰✰✰✰','✰✰✰✰✰'], datasets:[{label:'4. College Transport facility(on time pick-up, cleanliness, maintenance)',data:["+answerSet[0][3]+","+answerSet[1][3]+","+answerSet[2][3]+","+answerSet[3][3]+","+answerSet[4][3]+"]}]}}";
        String url5 = "https://quickchart.io/chart?devicePixelRatio=1.0&c={type:'bar',data:{labels:['✰','✰✰','✰✰✰','✰✰✰✰','✰✰✰✰✰'], datasets:[{label:'5. Examination activity(Organization of wpp, Extension activity)',data:["+answerSet[0][4]+","+answerSet[1][4]+","+answerSet[2][4]+","+answerSet[3][4]+","+answerSet[4][4]+"]}]}}";
        String url6 = "https://quickchart.io/chart?devicePixelRatio=1.0&c={type:'bar',data:{labels:['✰','✰✰','✰✰✰','✰✰✰✰','✰✰✰✰✰'], datasets:[{label:'6. Overall feedback',data:["+answerSet[0][5]+","+answerSet[1][5]+","+answerSet[2][5]+","+answerSet[3][5]+","+answerSet[4][5]+"]}]}}";
        
        urlSet[0]= url1;
        urlSet[1]= url2;
        urlSet[2]= url3;
        urlSet[3]= url4;
        urlSet[4]= url5;
        urlSet[5]= url6;
        
        


        return urlSet;
    }

    @Override
    public void CompletedStudent(String sid) throws RemoteException {
        PreparedStatement pst;
        ResultSet rs;
      
        try {
            Class.forName("com.mysql.jdbc.Driver");
            java.sql.Connection con = DriverManager.getConnection("jdbc:mysql://remotemysql.com:3306/pTuLo9BMYw","pTuLo9BMYw", "Je9bAr9W0e");
            pst = (PreparedStatement) con.prepareStatement("INSERT INTO `CompletedLis`(`StudentID`, `Satatus`) VALUES (?,?)");
            pst.setString(1, sid);
            pst.setString(2, "TAKEN");
            pst.executeUpdate();
          
        } catch (Exception e) {
            System.out.println(e.toString());
        }
    }

    @Override
    public ArrayList<String> getList() throws RemoteException {
        PreparedStatement pst;
        ResultSet rs;
        //clear completedList data when we press refresh button
        completedList.clear();

        try {
            Class.forName("com.mysql.jdbc.Driver");
            java.sql.Connection con = DriverManager.getConnection("jdbc:mysql://remotemysql.com:3306/pTuLo9BMYw","pTuLo9BMYw", "Je9bAr9W0e");
            pst = (PreparedStatement) con.prepareStatement("SELECT * FROM `CompletedLis`"); 
            rs = pst.executeQuery();
          
           while(rs.next()){
               completedList.add(rs.getString("StudentID"));
           }
   
        } catch (Exception e) {
            System.out.println(e.toString());
        }
        return completedList;
    }
    
}

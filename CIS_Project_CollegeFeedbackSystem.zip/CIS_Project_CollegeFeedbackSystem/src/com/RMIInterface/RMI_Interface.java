/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.RMIInterface;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Sarmila Sivaraja
 */
public interface RMI_Interface extends Remote {
    
   public boolean SignIn(String user , String pass) throws  RemoteException;
   public int[][] getFeedback(int ans[]) throws  RemoteException;
   public String[] genarateChart() throws  RemoteException;
   public void CompletedStudent( String sid) throws  RemoteException;
   public ArrayList<String> getList() throws  RemoteException;
    
}

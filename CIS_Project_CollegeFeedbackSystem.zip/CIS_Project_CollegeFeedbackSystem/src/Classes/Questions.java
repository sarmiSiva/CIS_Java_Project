/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

/**
 *
 * @author Sarmila Sivaraja
 */
public class Questions {
    
    String[][] questions = new String[3][6];

    public Questions() {
        this.questions[0][0]="1. Academics Syllabus content , Teaching method, Teaching guidance";
        this.questions[0][1]="2. Class room,internet, hostal, Library facilities";
        this.questions[0][2]="3. Events context, time management, venue arrangement";
        this.questions[0][3]="4. College Transport facility(on time pick-up, cleanliness, maintenance)";
        this.questions[0][4]="5. Examination activity(Organization of wpp, Extension activity)";
        this.questions[0][5]="6. Overall feedback";
    }

    public String[][] getQuestions() {
        return questions;
    }
}
